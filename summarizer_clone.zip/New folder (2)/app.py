import nltk
import os
import logging
import pickle # Import the pickle module
from flask import Flask, request, jsonify, render_template
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lex_rank import LexRankSummarizer
from sumy.nlp.stemmers import Stemmer
from sumy.utils import get_stop_words
import re

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Set NLTK Data Path ---
# This ensures NLTK looks for and downloads data into a directory relative to your app.py
nltk_data_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'nltk_data')
if not os.path.exists(nltk_data_dir):
    os.makedirs(nltk_data_dir)
    logging.info(f"Created NLTK data directory: {nltk_data_dir}")
nltk.data.path.append(nltk_data_dir)
logging.info(f"NLTK data path added: {nltk_data_dir}")
# --- End NLTK Data Path Setup ---

# Global variables
punkt_tokenizer_instance = None
stopwords_corpus_found = False

def ensure_nltk_data_and_load_tokenizer():
    global punkt_tokenizer_instance, stopwords_corpus_found

    # Path for the Punkt tokenizer pickle file
    punkt_tokenizer_path = os.path.join(nltk_data_dir, 'tokenizers', 'punkt', 'english.pickle')

    # Try to load Punkt tokenizer
    try:
        if os.path.exists(punkt_tokenizer_path):
            with open(punkt_tokenizer_path, 'rb') as f:
                punkt_tokenizer_instance = pickle.load(f)
            logging.info("NLTK 'punkt' tokenizer loaded directly from pickle.")
        else:
            logging.warning(f"NLTK 'punkt' tokenizer pickle not found at {punkt_tokenizer_path}. Attempting download.")
            nltk.download('punkt', download_dir=nltk_data_dir, quiet=True)
            if os.path.exists(punkt_tokenizer_path): # Check again after download
                with open(punkt_tokenizer_path, 'rb') as f:
                    punkt_tokenizer_instance = pickle.load(f)
                logging.info("NLTK 'punkt' tokenizer downloaded and loaded successfully.")
            else:
                logging.error(f"NLTK 'punkt' tokenizer pickle still not found after download attempt at {punkt_tokenizer_path}.")

    except Exception as e:
        logging.error(f"Error loading or downloading NLTK 'punkt' tokenizer: {e}")

    # Check for stopwords corpus
    try:
        nltk.data.find('corpora/stopwords')
        logging.info("NLTK 'stopwords' corpus found.")
        stopwords_corpus_found = True
    except nltk.downloader.DownloadError:
        logging.info("NLTK 'stopwords' corpus not found, downloading...")
        try:
            nltk.download('stopwords', download_dir=nltk_data_dir, quiet=True)
            logging.info("NLTK 'stopwords' corpus downloaded successfully.")
            stopwords_corpus_found = True
        except Exception as e:
            logging.error(f"Error downloading NLTK 'stopwords' corpus: {e}")
            stopwords_corpus_found = False
    except Exception as e:
        logging.error(f"Error checking/loading NLTK 'stopwords' corpus: {e}")
        stopwords_corpus_found = False

# Call this function once at the start of the app to ensure data is ready
ensure_nltk_data_and_load_tokenizer()

app = Flask(__name__, template_folder='templates', static_folder='static')

# --- Summarization Logic ---
def get_summary(text_content, ratio_target=0.3, language="english"):
    if not text_content or len(text_content.strip()) == 0:
        logging.warning("Received empty text content for summarization.")
        return ""

    text_content = re.sub(r'\s+', ' ', text_content).strip()

    if punkt_tokenizer_instance:
        # Use the global punkt_tokenizer_instance for sentence tokenization
        all_sentences = punkt_tokenizer_instance.tokenize(text_content)
    else:
        logging.error("Punkt tokenizer not loaded. Cannot tokenize sentences for summarization.")
        return ""

    total_sentences = len(all_sentences)

    if total_sentences == 0:
        logging.warning("No sentences could be extracted from the text.")
        return ""

    # Calculate sentences to extract based on ratio
    sentences_to_extract = max(1, int(total_sentences * ratio_target))

    # Ensure we don't try to extract more sentences than available
    sentences_to_extract = min(sentences_to_extract, total_sentences)

    # If the target is to return most or all sentences, just return original text
    if sentences_to_extract >= total_sentences * 0.95 and total_sentences > 5: # Threshold to avoid summarizing if nearly all sentences are selected
        logging.info(f"Returning original text as target ratio ({ratio_target}) implies most sentences ({sentences_to_extract}/{total_sentences}).")
        return text_content
    elif total_sentences <= 1: # If only one sentence, return it as is
        return text_content


    parser = PlaintextParser.from_string(text_content, Tokenizer(language))
    stemmer = Stemmer(language)

    summarizer = LexRankSummarizer(stemmer)
    if stopwords_corpus_found:
        try:
            summarizer.stop_words = get_stop_words(language)
        except LookupError:
            logging.warning(f"Stopwords for language '{language}' not found. Using default or no stopwords.")
            # Fallback if language specific stopwords not available
    else:
        logging.warning("Stopwords corpus not found, proceeding without stopwords.")

    try:
        # Use the calculated number of sentences to extract
        summary_sentences = summarizer(parser.document, sentences_count=sentences_to_extract)
        summary = " ".join([str(sentence) for sentence in summary_sentences])
        logging.info(f"Summarized text into {len(summary_sentences)} sentences (target: {sentences_to_extract}).")
        return summary
    except Exception as e:
        logging.error(f"Error during summarization: {e}")
        return ""


# --- Flask Routes ---

@app.route('/')
def home():
    logging.info("Serving index.html")
    return render_template('index.html')

@app.route('/api/summarize', methods=['POST'])
def summarize_api():
    logging.info("Received /api/summarize POST request.")
    data = request.get_json()
    content = data.get('text') # Changed from 'content' to 'text' to match JS
    ratio = data.get('ratio') # Get the ratio directly from JS
    language = data.get('language', 'english').lower()

    if not content or len(content.strip()) == 0:
        logging.warning("No content provided in the summarization request.")
        return jsonify({"summary": "", "error": "No content provided for summarization."}), 400

    if not isinstance(ratio, (int, float)) or not (0.0 <= ratio <= 1.0):
        logging.warning(f"Invalid ratio received: {ratio}. Defaulting to 0.3.")
        ratio = 0.3 # Default ratio if invalid or missing

    # No need to count sentences here and determine target sentences manually.
    # The 'get_summary' function will calculate it based on the ratio and actual content.

    logging.info(f"Attempting to summarize with ratio {ratio} for language '{language}'.")
    summary = get_summary(content, ratio_target=ratio, language=language)

    if not summary:
        logging.warning("Summarization returned an empty result. Sending back original text.")
        return jsonify({"summary": content, "error": "Summarization produced an empty result for the given text. Returning original content."}), 200

    logging.info("Summarization successful.")
    return jsonify({"summary": summary})

if __name__ == '__main__':
    logging.info("Starting Flask development server.")
    app.run(debug=True, port=5000)