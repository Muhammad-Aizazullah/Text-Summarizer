document.addEventListener('DOMContentLoaded', () => {
    // Get references to the new text areas and buttons
    const inputText = document.getElementById('inputText'); // Correctly target input textarea by ID
    const summaryOutput = document.getElementById('summaryOutput'); // Correctly target output textarea by ID
    const summarizeBtn = document.getElementById('summarizeBtn'); // Get the main summarize button by ID
    const sampleTextBtn = document.getElementById('sampleText'); // ID is on the div. For the option-box clicks
    const pasteTextBtn = document.getElementById('pasteText');
    const addUrlBtn = document.getElementById('addUrl');
    const copySummaryBtn = document.getElementById('copySummaryBtn'); // Get the copy button
    const lengthSlider = document.getElementById('lengthSlider'); // Get the slider
    const currentLanguageElement = document.querySelector('.language-text'); // Assuming this shows current language

    // Tab switching functionality (existing, no change needed)
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            // In a real application, you might use data-tab to switch content
            // const tabId = button.dataset.tab;
            // console.log(`Switched to tab: ${tabId}`);
            // You would then show/hide content related to that tabId
        });
    });

    // Option Box Click Effects (Sample Text, Add URL, Paste Text)
    // IMPORTANT: Make sure your HTML for these buttons uses the IDs 'sampleText', 'addUrl', 'pasteText'
    if (sampleTextBtn) {
        sampleTextBtn.addEventListener('click', () => {
            inputText.value = "This is some sample text that you can use to test the summarization feature. In a real application, clicking this button would load a pre-defined block of text into the input area. This allows users to quickly see how the summarizer works without having to type or paste their own content. The goal is to provide a seamless user experience for demonstrating the core functionality of the AI summarizer tool. Remember, this is just dummy text for demonstration purposes. The summarizer should be able to identify the most important sentences and present them concisely, helping users grasp the main idea quickly.";
            summaryOutput.value = ''; // Clear previous summary
            if (copySummaryBtn) copySummaryBtn.style.display = 'none'; // Hide copy button
        });
    }

    if (pasteTextBtn) {
        pasteTextBtn.addEventListener('click', async () => {
            try {
                const text = await navigator.clipboard.readText();
                inputText.value = text;
                summaryOutput.value = ''; // Clear previous summary
                if (copySummaryBtn) copySummaryBtn.style.display = 'none'; // Hide copy button
                alert('Text pasted from clipboard (if permission granted)!');
            } catch (err) {
                console.error('Failed to read clipboard contents: ', err);
                alert('Could not paste from clipboard. Please paste manually or grant permission.');
            }
        });
    }

    if (addUrlBtn) {
        addUrlBtn.addEventListener('click', () => {
            const url = prompt("Please enter the URL:");
            if (url) {
                alert(`You entered URL: ${url}. (URL fetching not implemented in this frontend version. Requires backend processing.)`);
                // You would typically send this URL to your backend
                // Your backend would then fetch the content, extract text, and return it for summarization.
                // For now, it's just an alert.
            }
        });
    }

    // Main Summarize Button Logic
    if (summarizeBtn) {
        summarizeBtn.addEventListener('click', async () => {
            const content = inputText.value.trim(); // Get text from input textarea
            const sliderValue = lengthSlider.value; // Get the slider value (0-100)
            const language = currentLanguageElement.textContent.toLowerCase(); // Get current language, e.g., 'en'

            if (!content) {
                alert('Please enter some text to summarize.');
                return;
            }

            summaryOutput.value = 'Summarizing... Please wait.'; // Show a loading message in output
            summarizeBtn.textContent = "Summarizing..."; // Update button text
            summarizeBtn.disabled = true; // Disable button to prevent multiple clicks
            if (copySummaryBtn) copySummaryBtn.style.display = 'none'; // Hide copy button during summarization

            try {
                // Convert slider value (0-100) to a ratio suitable for summarization (e.g., 0.1 to 0.9)
                // If slider 0 = short (0.1 ratio), slider 100 = long (0.9 ratio)
                const ratio = (parseInt(sliderValue) / 100) * 0.8 + 0.1; // Maps 0-100 to 0.1-0.9

                const response = await fetch('/api/summarize', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ text: content, ratio: ratio, language: language }) // Send ratio and language
                });

                const result = await response.json(); // Parse response JSON

                if (response.ok) {
                    summaryOutput.value = result.summary; // Display summarized text in output textarea
                    if (copySummaryBtn) copySummaryBtn.style.display = 'block'; // Show copy button
                    // alert('Text summarized successfully!'); // Optional: removed alert for smoother UX
                } else {
                    // Handle errors from the backend
                    alert(`Error: ${result.error || 'Something went wrong on the server.'}`);
                    console.error("Summarization error:", result.error);
                    summaryOutput.value = `Error: ${result.error || 'Could not summarize.'}`; // Show error in output box
                }
            } catch (error) {
                // Handle network or other fetch-related errors
                console.error('Network or fetch error:', error);
                alert('Failed to connect to the summarization service. Please ensure your backend is running.');
                summaryOutput.value = 'Error: Failed to connect to service.';
            } finally {
                summarizeBtn.textContent = "Summarize"; // Reset button text
                summarizeBtn.disabled = false; // Re-enable the button
            }
        });
    }

    // Copy Summary Button Logic
    if (copySummaryBtn) {
        copySummaryBtn.addEventListener('click', () => {
            summaryOutput.select(); // Select the text in the output textarea
            summaryOutput.setSelectionRange(0, 99999); // For mobile devices to select all text
            try {
                document.execCommand('copy'); // Copy the selected text
                alert('Summary copied to clipboard!');
            } catch (err) {
                console.error('Failed to copy text: ', err);
                alert('Failed to copy text. Please copy manually.');
            }
        });
    }

    // File Input (Drag & Drop or Browse)
    const fileInput = document.getElementById('fileInput');
    const dragDropArea = document.querySelector('.drag-drop-area'); // Corrected from browseButton

    // Handle file selection via browse button (which is linked to fileInput)
    if (fileInput) {
        fileInput.addEventListener('change', async (event) => {
            const files = event.target.files;
            if (files.length > 0) {
                // alert(`Selected file: ${files[0].name}. (File content reading not implemented in frontend yet)`); // Remove this alert for better UX
                console.log('File selected:', files[0]);

                // IMPORTANT: For actual file processing, you'd typically use FormData
                // and send the file to a different backend endpoint.
                // For demonstration, let's try reading plain text files directly
                if (files[0].type === 'text/plain' || files[0].name.toLowerCase().endsWith('.txt')) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        inputText.value = e.target.result;
                        summaryOutput.value = ''; // Clear previous summary
                        if (copySummaryBtn) copySummaryBtn.style.display = 'none'; // Hide copy button
                        alert("Text file content loaded into input area.");
                    };
                    reader.readAsText(files[0]);
                } else {
                    alert("Only plain text (.txt) files are directly readable by the browser for this demo. For other formats (doc, pdf, image), backend processing is required.");
                }
            }
        });
    }


    // Handle drag and drop
    if (dragDropArea) {
        dragDropArea.addEventListener('dragover', (event) => {
            event.preventDefault(); // Prevent default to allow drop
            dragDropArea.style.borderColor = '#1976D2'; // Highlight on drag over
            dragDropArea.style.backgroundColor = '#e0f2ff';
        });

        dragDropArea.addEventListener('dragleave', () => {
            dragDropArea.style.borderColor = '#a0d8ff'; // Reset on drag leave
            dragDropArea.style.backgroundColor = '#eaf6ff';
        });

        dragDropArea.addEventListener('drop', async (event) => {
            event.preventDefault(); // Prevent default action (opening file in new tab)
            dragDropArea.style.borderColor = '#a0d8ff'; // Reset
            dragDropArea.style.backgroundColor = '#eaf6ff';

            const files = event.dataTransfer.files;
            if (files.length > 0) {
                // alert(`Dropped file: ${files[0].name}. (File content reading not implemented in frontend yet)`); // Remove this alert
                console.log('File dropped:', files[0]);

                if (files[0].type === 'text/plain' || files[0].name.toLowerCase().endsWith('.txt')) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        inputText.value = e.target.result;
                        summaryOutput.value = ''; // Clear previous summary
                        if (copySummaryBtn) copySummaryBtn.style.display = 'none'; // Hide copy button
                        alert("Text file content loaded into input area.");
                    };
                    reader.readAsText(files[0]);
                } else {
                    alert("Only plain text (.txt) files are directly readable by the browser for this demo. For other formats (doc, pdf, image), backend processing is required.");
                }
            }
        });
    }

    // Length Slider (visual only) - no change needed here, value is read on summarize click
    if (lengthSlider) {
        lengthSlider.addEventListener('input', (event) => {
            // You could update a value displayed to the user here
            // console.log('Slider value:', event.target.value);
        });
    }
});